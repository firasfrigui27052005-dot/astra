
# ASTRA-SAFE Virtual Prototype (Web Demo)

This is a self-contained interactive web demo representing the ASTRA-SAFE virtual prototype for a 3U CubeSat.
It uses Three.js for the 3D visualization and Chart.js for telemetry plotting. The demo simulates telemetry and a simple anomaly detector and demonstrates recovery actions.

## How to run locally
1. Unzip the package.
2. Open `index.html` in a modern browser (Chrome/Edge/Firefox). For full local file access, you may serve the folder via a simple static server:

```bash
# Python 3
python -m http.server 8000
# then open http://localhost:8000 in your browser
```

## Files
- `index.html` : single-file demo (3D view, charts, simulation)
- `README.md` : this file

