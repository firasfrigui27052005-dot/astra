
# ASTRA-SAFE — Virtual Prototype (Web Demo)

**ASTRA-SAFE** — Autonomous Smart Telemetry & Recovery AI for CubeSats  
This repository contains a lightweight interactive *virtual prototype* (web demo) of the ASTRA-SAFE 3U CubeSat module.

## Demo contents
- `index.html` — single-file interactive demo (Three.js 3D view + Chart.js telemetry)
- `README.md` — this file

The demo simulates telemetry (voltage, temperature, gyro), runs a simple in-browser anomaly detector and shows automated recovery actions (visual + log).

## How to run locally
1. Download / clone the repository.
2. Serve the folder (recommended) or open `index.html` directly.

**Serve with Python (recommended):**
```bash
# from repository root
python -m http.server 8000
# open http://localhost:8000 in your browser
```

**Or open** `index.html` directly in a modern browser (Chrome/Edge/Firefox). If scripts are blocked when opening file://, use the Python server method.

## Interacting with the demo
- Rotate/zoom the 3D CubeSat with your mouse.
- Use the buttons to inject faults:
  - Inject Power Fault
  - Inject Thermal Fault
  - Inject ADCS Fault
- Watch the telemetry graph and the Actions Log — the demo will simulate detection and recovery.

## How to host on GitHub Pages
1. Create a GitHub repository (example name: `ASTRA-SAFE-VirtualPrototype`).
2. Upload the files (`index.html`, `README.md`) using **Add file → Upload files**.
3. Commit and go to **Settings → Pages** to enable GitHub Pages (choose `main` / root). After a few minutes the demo will be live.

## License & attribution
Use for the IEEE IES & AESS Challenge demo. Modify freely for prototypes, academic demos, and presentations. Please do not publish private personal data inside the repo.
